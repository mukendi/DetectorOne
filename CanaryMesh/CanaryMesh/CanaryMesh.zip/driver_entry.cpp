// Copyright (c) 2026, Simon Ngoy. All rights reserved.
// Use of this source code is governed by a MIT license.
//
// CanaryMesh.cpp � CanaryMesh EDR Canary Driver
//
// Modifications appliqu�es :
//   1. Includes corrig�s � ntifs.h seul suffit (wdm.h + ntddk.h retir�s)
//   2. Enregistrement via IOCTL (\Device\KratosEDR) au lieu de
//      MmGetSystemRoutineAddress (qui ne r�sout que ntoskrnl/hal)
//   3. Un seul IOCTL retourne : table + adresses callbacks + compteurs
//   4. Code mort (fnRegister comment� + r�f�rences orphelines) nettoy�

#include <ntifs.h>      // Tout le kernel � inclut wdm.h et ntddk.h
#include <ntimage.h>    // Structures PE
#include <ntstrsafe.h>  // RtlStringCchCopyW
#include <intrin.h>     // Intrins�ques compilateur



#define CANARY_POOL_TAG                     'yrCK'
// V�rifier que les defines arrivent bien depuis la configuration du projet
#ifndef CANARY_ID
#error "CANARY_ID must be defined in project Preprocessor Definitions (1, 2 or 3)"
#endif

#ifndef CANARY_SERVICE_NAME
#error "CANARY_SERVICE_NAME must be defined in project Preprocessor Definitions"
#endif

#define KRATOS_DEVICE_NAME    L"\\Device\\KratosEDR"

// IOCTL partag� avec DetectorOne
#define IOCTL_KRATOS_REGISTER CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, \
                                   METHOD_BUFFERED, FILE_ANY_ACCESS)

#define CanaryMesh_MAX_CANARIES             5
#define CanaryMesh_HEARTBEAT_INTERVAL_MS    2000
#define CanaryMesh_HEARTBEAT_TIMEOUT_MS     6000
#define CanaryMesh_DRIVER_POLL_INTERVAL_MS  1500
#define CanaryMesh_CALLBACK_CHECK_INTERVAL_MS 2000
#define CanaryMesh_HANDOFF_TIMEOUT_MS       15000
#define CanaryMesh_ALERT_WINDOW_MS          120000
#define CanaryMesh_LIVENESS_WINDOW_MS       10000
#define CanaryMesh_FAST_UNLOAD_THRESHOLD_MS 30000

// ============================================================
// Structures IOCTL � partag�es avec DetectorOne (KratosShared.h)
// ============================================================
#pragma pack(push, 8)
typedef struct _KRATOS_REGISTER_REQUEST {
    ULONG   CanaryId;
    PVOID   DriverObjectAddress;
    PVOID   AlertEntryPoint;
} KRATOS_REGISTER_REQUEST, * PKRATOS_REGISTER_REQUEST;

// La r�ponse retourne TOUT ce dont le canari a besoin en un seul appel :
//   - Pointeur vers la table partag�e
//   - Adresses exactes des callbacks DetectorOne
//   - Pointeurs vers les compteurs de vivacit�
typedef struct _KRATOS_REGISTER_RESPONSE {
    NTSTATUS    Status;

    // Table partag�e
    PVOID       TablePointer;

    // Adresses des callbacks DetectorOne
    // Utilis�es par Signal A pour v�rifier leur pr�sence dans les tableaux kernel
    PVOID       ProcessCallbackAddress;
    PVOID       ImageCallbackAddress;
    PVOID       ThreadCallbackAddress;

    // Pointeurs vers les compteurs de vivacit� dans DetectorOne
    // Utilis�s par Signal B pour d�tecter si les callbacks sont encore invoqu�s
    PVOID       ProcessEventCounterPtr;
    PVOID       ImageEventCounterPtr;

} KRATOS_REGISTER_RESPONSE, * PKRATOS_REGISTER_RESPONSE;

// Assertions de compilation � �chouent si layout diff�rent
C_ASSERT(sizeof(KRATOS_REGISTER_REQUEST) == 24);
C_ASSERT(sizeof(KRATOS_REGISTER_RESPONSE) == 56);
C_ASSERT(FIELD_OFFSET(KRATOS_REGISTER_REQUEST, AlertEntryPoint) == 16);
C_ASSERT(FIELD_OFFSET(KRATOS_REGISTER_RESPONSE, ProcessCallbackAddress) == 16);
// ============================================================
// Types partag�s avec DetectorOne
// ============================================================

typedef enum _CANARY_STATUS {
    CANARY_STATUS_UNKNOWN = 0,
    CANARY_STATUS_ALIVE = 1,
    CANARY_STATUS_SUSPECTED = 2,
    CANARY_STATUS_DEAD = 3
} CANARY_STATUS;

typedef enum _CanaryMesh_ALERT_TYPE {
    ALERT_NONE = 0,
    ALERT_CALLBACK_POINTER_REMOVED = 1,
    ALERT_CALLBACK_LIVENESS_FROZEN = 2,
    ALERT_DRIVER_UNLOADED_FAST = 3,
    ALERT_DRIVER_LOADED_CALLBACKS_DEAD = 4,
    ALERT_CANARY_PEER_DEAD = 5,
    ALERT_QUORUM_LOST = 6,
} CanaryMesh_ALERT_TYPE;

// Structure KLDR_DATA_TABLE_ENTRY � kernel mode
// D�finie manuellement pour compatibilit� maximale entre builds WDK
typedef struct _KLDR_DATA_TABLE_ENTRY {
    LIST_ENTRY      InLoadOrderLinks;
    PVOID           ExceptionTable;
    ULONG           ExceptionTableSize;
    PVOID           GpValue;
    PVOID           NonPagedDebugInfo;
    PVOID           DllBase;
    PVOID           EntryPoint;
    ULONG           SizeOfImage;
    UNICODE_STRING  FullDllName;
    UNICODE_STRING  BaseDllName;
    ULONG           Flags;
    USHORT          LoadCount;
    USHORT          TlsIndex;
} KLDR_DATA_TABLE_ENTRY, * PKLDR_DATA_TABLE_ENTRY;

typedef struct _CANARY_IDENTITY {
    ULONG           CanaryId;
    WCHAR           ServiceName[64];
    PVOID           DriverObjectAddress;
    PVOID           AlertEntryPoint;
    LARGE_INTEGER   RegistrationTime;
    ULONG           RegistrationPid;
    volatile LONG   Status;
    volatile LONG64 LastHeartbeatTime;
    volatile LONG   HeartbeatSequence;
} CANARY_IDENTITY, * PCANARY_IDENTITY;

typedef struct _CanaryMesh_EDR_CALLBACK_BASELINE {
    PVOID               ProcessCallbackAddress;
    PVOID               ImageCallbackAddress;
    PVOID               ThreadCallbackAddress;
    volatile LONG64* ProcessEventCounter;
    volatile LONG64* ImageEventCounter;
    LONG64              BaselineProcessCount;
    LONG64              BaselineImageCount;
    LARGE_INTEGER       BaselineCaptureTime;
    BOOLEAN             Valid;
} CanaryMesh_EDR_CALLBACK_BASELINE, * PCanaryMesh_EDR_CALLBACK_BASELINE;

typedef struct _CanaryMesh_CANARY_TABLE {
    ULONG               Magic;
    ULONG               Version;
    volatile LONG       RegisteredCount;
    volatile LONG       AliveCount;
    ULONG               ExpectedCount;
    volatile LONG       HandoffComplete;
    ULONG               QuorumRequired;
    volatile LONG       AlertGeneration;
    volatile LONG       AlertVotes;
    volatile LONG       AlertActive;
    volatile LONG       AlertVoteBitmap;
    volatile LONG       ConsensusEmitted;
    WCHAR               SuspectDriverName[260];
    LARGE_INTEGER       SuspectDriverLoadTime;
    ULONG               SuspectDriverRiskScore;
    volatile LONG       AlertDispatched;
    CANARY_IDENTITY     Canaries[CanaryMesh_MAX_CANARIES];
    CanaryMesh_EDR_CALLBACK_BASELINE CallbackBaseline;
    volatile LONG       SuspectDriverStillLoaded;
    WCHAR               SuspectDriverTracked[260];
} CanaryMesh_CANARY_TABLE, *PCanaryMesh_CANARY_TABLE;

// ============================================================
// Contexte alerte active
// ============================================================

typedef struct _CANARY_ALERT_CONTEXT {
    volatile LONG       Active;
    WCHAR               DriverName[260];
    LARGE_INTEGER       LoadTimestamp;
    ULONG               RiskScore;
    LARGE_INTEGER       ActivationTime;
    volatile LONG       DriverStillLoaded;
    volatile LONG       UnloadDetected;
    LARGE_INTEGER       UnloadTimestamp;
    volatile LONG       CallbackRemovalDetected;
    volatile LONG       LivenessDropDetected;
    LARGE_INTEGER       CallbackLossTimestamp;
    volatile LONG       DetectedSignals;
} CANARY_ALERT_CONTEXT, * PCANARY_ALERT_CONTEXT;

typedef struct _EX_CALLBACK_ROUTINE_BLOCK {
    EX_RUNDOWN_REF  RundownProtect;  // 8 bytes � offset 0
    PVOID           Function;         // 8 bytes � offset 8 ? adresse r�elle
    PVOID           Context;          // 8 bytes � offset 16
} EX_CALLBACK_ROUTINE_BLOCK, * PEX_CALLBACK_ROUTINE_BLOCK;

// ============================================================
// �tat global du canari
// ============================================================

typedef struct _CANARY_GLOBAL_STATE {
    ULONG                       CanaryId;
    PCanaryMesh_CANARY_TABLE    Table;
    PETHREAD                    HeartbeatThread;
    PETHREAD                    DriverWatchThread;
    PETHREAD                    CallbackWatchThread;
    volatile LONG               ShouldStop;
    CANARY_ALERT_CONTEXT        Alert;
    KEVENT                      AlertEvent;
    FAST_MUTEX                  AlertLock;
    BOOLEAN                     SignalAProcessBaselineValid;
    BOOLEAN                     SignalAImageBaselineValid;
    BOOLEAN                     SignalAThreadBaselineValid;
    BOOLEAN                     LivenessObservedAfterAlert;
    LONG64                      LivenessProcessBaseline;
    LONG64                      LivenessImageBaseline;
    LARGE_INTEGER               LivenessBaselineCaptureTime;
} CANARY_GLOBAL_STATE;

static CANARY_GLOBAL_STATE g_State = { 0 };
// Cached after a baseline-positive scan. Do not cache the first LEA target:
// PsSet* routines reference locks and helper globals before the real table.
static PVOID g_ProcessCallbackTableAddress = NULL;
static PVOID g_ImageCallbackTableAddress = NULL;
static PVOID g_ThreadCallbackTableAddress = NULL;
// ============================================================
// Forward declarations
// ============================================================

DRIVER_UNLOAD   CanaryUnload;
VOID            CanaryHeartbeatThread(PVOID Context);
VOID            CanaryDriverWatchThread(PVOID Context);
VOID            CanaryCallbackWatchThread(PVOID Context);
NTSTATUS        CanaryRegisterWithDetectorOne(IN PDRIVER_OBJECT DriverObject);
NTSTATUS        CanaryWaitForHandoff(IN PCanaryMesh_CANARY_TABLE Table);
BOOLEAN         CanaryVerifyCallbackPointerInTable(IN PVOID TargetCallback);
BOOLEAN         CanaryVerifyCallbackPointerForRoutine(
    IN PCWSTR RoutineName,
    IN PVOID TargetCallback,
    IN OUT PVOID* CachedTable);
BOOLEAN         CanaryCallbackTableContains(
    IN PVOID TableAddress,
    IN PVOID TargetCallback,
    IN BOOLEAN Verbose);
PVOID           CanaryFindCallbackTableForRoutine(
    IN PCWSTR RoutineName,
    IN PVOID TargetCallback);
PVOID           CanaryFindCallbackTableInCode(
    IN PUCHAR FunctionAddress,
    IN PCWSTR RoutineName,
    IN PVOID TargetCallback,
    IN ULONG Depth);
BOOLEAN         CanaryIsLivenessCounterFrozen();
BOOLEAN         CanaryIsSuspectDriverLoaded(IN PWSTR DriverName);
VOID            CanaryCastVote(IN CanaryMesh_ALERT_TYPE AlertType);
VOID            CanaryEmitConsensusAlert(IN CanaryMesh_ALERT_TYPE AlertType,
    IN LONG Votes);
VOID            CanaryLogState(IN PCSTR Context);

extern "C" VOID NTAPI CanaryReceiveAlert(
    IN PWSTR            DriverName,
    IN PLARGE_INTEGER   LoadTimestamp,
    IN ULONG            RiskScore
);

extern "C" LIST_ENTRY   PsLoadedModuleList;
extern "C" PERESOURCE    PsLoadedModuleResource;


volatile LONG   HasVotedThisRound;  // 0=non vot�, 1=vot�
// ============================================================
// DriverEntry
// ============================================================

extern "C"
NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    UNREFERENCED_PARAMETER(RegistryPath);
    NTSTATUS status;

    DbgPrint("[CanaryMesh%lu] DriverEntry\n", (ULONG)CANARY_ID);

    RtlZeroMemory(&g_State, sizeof(g_State));
    g_State.CanaryId = CANARY_ID;
    g_State.ShouldStop = 0;

    ExInitializeFastMutex(&g_State.AlertLock);
    KeInitializeEvent(&g_State.AlertEvent, NotificationEvent, FALSE);

    DriverObject->DriverUnload = CanaryUnload;

    // -- Phase 1+2 : Enregistrement via IOCTL -----------------
    // Remplace MmGetSystemRoutineAddress qui ne r�sout pas les
    // exports d'autres drivers � uniquement ntoskrnl.exe et hal.dll
    status = CanaryRegisterWithDetectorOne(DriverObject);
    if (!NT_SUCCESS(status)) {
        DbgPrint("[CanaryMesh%lu] Registration failed 0x%08X\n",
            (ULONG)CANARY_ID, status);
        return status;
    }
    // -- Phase 3 : V�rification sanity de la baseline ---------
    // La baseline a �t� remplie par CanaryRegisterWithDetectorOne
    // depuis la r�ponse IOCTL � v�rifier imm�diatement au d�marrage
    PCanaryMesh_EDR_CALLBACK_BASELINE baseline =
        &g_State.Table->CallbackBaseline;

    if (baseline->Valid) {
        DbgPrint("[CanaryMesh%lu] Callback baseline received:\n",
            (ULONG)CANARY_ID);
        DbgPrint("[CanaryMesh%lu]   ProcessCallback = %p\n",
            (ULONG)CANARY_ID, baseline->ProcessCallbackAddress);
        DbgPrint("[CanaryMesh%lu]   ImageCallback   = %p\n",
            (ULONG)CANARY_ID, baseline->ImageCallbackAddress);
        DbgPrint("[CanaryMesh%lu]   ThreadCallback  = %p\n",
            (ULONG)CANARY_ID, baseline->ThreadCallbackAddress);
        // Signal A is enabled for every callback class that is observable on this Windows build.
        g_State.SignalAProcessBaselineValid =
            CanaryVerifyCallbackPointerForRoutine(
                L"PsSetCreateProcessNotifyRoutineEx",
                baseline->ProcessCallbackAddress,
                &g_ProcessCallbackTableAddress);
        if (!g_State.SignalAProcessBaselineValid) {
            g_State.SignalAProcessBaselineValid =
                CanaryVerifyCallbackPointerForRoutine(
                    L"PsSetCreateProcessNotifyRoutine",
                    baseline->ProcessCallbackAddress,
                    &g_ProcessCallbackTableAddress);
        }
        g_State.SignalAImageBaselineValid =
            CanaryVerifyCallbackPointerForRoutine(
                L"PsSetLoadImageNotifyRoutine",
                baseline->ImageCallbackAddress,
                &g_ImageCallbackTableAddress);
        g_State.SignalAThreadBaselineValid =
            CanaryVerifyCallbackPointerForRoutine(
                L"PsSetCreateThreadNotifyRoutine",
                baseline->ThreadCallbackAddress,
                &g_ThreadCallbackTableAddress);
        DbgPrint("[CanaryMesh%lu] Signal A baselines: Process=%u Image=%u Thread=%u\n",
            (ULONG)CANARY_ID,
            (ULONG)g_State.SignalAProcessBaselineValid,
            (ULONG)g_State.SignalAImageBaselineValid,
            (ULONG)g_State.SignalAThreadBaselineValid);
        if (!g_State.SignalAProcessBaselineValid &&
            !g_State.SignalAImageBaselineValid &&
            !g_State.SignalAThreadBaselineValid) {
            DbgPrint("[CanaryMesh%lu] WARNING: no callback baseline found; Signal A disabled for this boot\n",
                (ULONG)CANARY_ID);
        }
    }

    // -- Phase 5 : D�marrer les trois threads -----------------
    HANDLE hThread = NULL;

    // Thread 1 : Heartbeat P2P
    status = PsCreateSystemThread(&hThread, THREAD_ALL_ACCESS,
        NULL, NULL, NULL, CanaryHeartbeatThread, &g_State);
    if (!NT_SUCCESS(status)) return status;
    ObReferenceObjectByHandle(hThread, THREAD_ALL_ACCESS, *PsThreadType,
        KernelMode, (PVOID*)&g_State.HeartbeatThread, NULL);
    ZwClose(hThread);

    // Thread 2 : Driver Watch (PsLoadedModuleList � Signal C)
    status = PsCreateSystemThread(&hThread, THREAD_ALL_ACCESS,
        NULL, NULL, NULL, CanaryDriverWatchThread, &g_State);
    if (!NT_SUCCESS(status)) return status;
    ObReferenceObjectByHandle(hThread, THREAD_ALL_ACCESS, *PsThreadType,
        KernelMode, (PVOID*)&g_State.DriverWatchThread, NULL);
    ZwClose(hThread);

    // Thread 3 : Callback Watch (Signal A + Signal B)
    status = PsCreateSystemThread(&hThread, THREAD_ALL_ACCESS,
        NULL, NULL, NULL, CanaryCallbackWatchThread, &g_State);
    if (!NT_SUCCESS(status)) return status;
    ObReferenceObjectByHandle(hThread, THREAD_ALL_ACCESS, *PsThreadType,
        KernelMode, (PVOID*)&g_State.CallbackWatchThread, NULL);
    ZwClose(hThread);

    DbgPrint("[CanaryMesh%lu] Loaded � three surveillance threads active\n",
        (ULONG)CANARY_ID);

    return STATUS_SUCCESS;
}

// ============================================================
// CanaryRegisterWithDetectorOne
//
// Ouvre \Device\KratosEDR et envoie IOCTL_KRATOS_REGISTER.
// La r�ponse retourne en une seule fois :
//   - Pointeur vers la table partag�e
//   - Adresses des callbacks DetectorOne (baseline Signal A)
//   - Pointeurs vers les compteurs de vivacit� (baseline Signal B)
// ============================================================

NTSTATUS CanaryRegisterWithDetectorOne(IN PDRIVER_OBJECT DriverObject) {
    NTSTATUS status;
    UNICODE_STRING deviceName;
    PFILE_OBJECT    fileObject = NULL;
    PDEVICE_OBJECT  devObject = NULL;

    RtlInitUnicodeString(&deviceName, KRATOS_DEVICE_NAME);

    // Ouvrir le device de DetectorOne
    status = IoGetDeviceObjectPointer(
        &deviceName,
        FILE_READ_DATA,
        &fileObject,
        &devObject
    );
    if (!NT_SUCCESS(status)) {
        DbgPrint("[CanaryMesh%lu] Cannot open %S Status=0x%08X "
            "� is DetectorOne loaded?\n",
            (ULONG)CANARY_ID, KRATOS_DEVICE_NAME, status);
        return status;
    }

    // Allouer le buffer IOCTL (METHOD_BUFFERED = m�me buffer in/out)
    ULONG bufferSize = max(sizeof(KRATOS_REGISTER_REQUEST),
        sizeof(KRATOS_REGISTER_RESPONSE));

    PVOID buffer = ExAllocatePool2(
        POOL_FLAG_NON_PAGED, bufferSize, CANARY_POOL_TAG);
    if (!buffer) {
        ObDereferenceObject(fileObject);
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    RtlZeroMemory(buffer, bufferSize);

    // Remplir la requ�te
    PKRATOS_REGISTER_REQUEST req = (PKRATOS_REGISTER_REQUEST)buffer;
    req->CanaryId = CANARY_ID;
    req->DriverObjectAddress = (PVOID)DriverObject;
    req->AlertEntryPoint = (PVOID)CanaryReceiveAlert;

    // Construire et envoyer l'IRP de fa�on synchrone
    KEVENT event;
    KeInitializeEvent(&event, NotificationEvent, FALSE);

    IO_STATUS_BLOCK ioStatus = { 0 };

    PIRP irp = IoBuildDeviceIoControlRequest(
        IOCTL_KRATOS_REGISTER,
        devObject,
        buffer, sizeof(KRATOS_REGISTER_REQUEST),    // Input
        buffer, sizeof(KRATOS_REGISTER_RESPONSE),   // Output
        FALSE,
        &event,
        &ioStatus
    );

    if (!irp) {
        ExFreePoolWithTag(buffer, CANARY_POOL_TAG);
        ObDereferenceObject(fileObject);
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    status = IoCallDriver(devObject, irp);
    if (status == STATUS_PENDING) {
        KeWaitForSingleObject(&event, Executive, KernelMode, FALSE, NULL);
        status = ioStatus.Status;
    }

    if (!NT_SUCCESS(status)) {
        DbgPrint("[CanaryMesh%lu] IOCTL_KRATOS_REGISTER failed "
            "0x%08X\n", (ULONG)CANARY_ID, status);
        ExFreePoolWithTag(buffer, CANARY_POOL_TAG);
        ObDereferenceObject(fileObject);
        return status;
    }

    // Extraire la r�ponse
    PKRATOS_REGISTER_RESPONSE resp = (PKRATOS_REGISTER_RESPONSE)buffer;

    if (!NT_SUCCESS(resp->Status)) {
        DbgPrint("[CanaryMesh%lu] Registration rejected by DetectorOne "
            "0x%08X\n", (ULONG)CANARY_ID, resp->Status);
        ExFreePoolWithTag(buffer, CANARY_POOL_TAG);
        ObDereferenceObject(fileObject);
        return resp->Status;
    }

    // Valider et enregistrer le pointeur table
    PCanaryMesh_CANARY_TABLE table =
        (PCanaryMesh_CANARY_TABLE)resp->TablePointer;

    if (!table || table->Magic != 0x4B524154) {
        DbgPrint("[CanaryMesh%lu] Invalid table pointer or magic\n",
            (ULONG)CANARY_ID);
        ExFreePoolWithTag(buffer, CANARY_POOL_TAG);
        ObDereferenceObject(fileObject);
        return STATUS_INVALID_ADDRESS;
    }

    g_State.Table = table;

    // Remplir la baseline directement depuis la r�ponse IOCTL
    // (plus besoin d'appels s�par�s fnGetCallbacks / fnGetCounters)
    PCanaryMesh_EDR_CALLBACK_BASELINE baseline = &table->CallbackBaseline;

    baseline->ProcessCallbackAddress = resp->ProcessCallbackAddress;
    baseline->ImageCallbackAddress = resp->ImageCallbackAddress;
    baseline->ThreadCallbackAddress = resp->ThreadCallbackAddress;
    baseline->ProcessEventCounter =
        (volatile LONG64*)resp->ProcessEventCounterPtr;
    baseline->ImageEventCounter =
        (volatile LONG64*)resp->ImageEventCounterPtr;
    baseline->Valid = TRUE;
    KeQuerySystemTime(&g_State.LivenessBaselineCaptureTime);

    DbgPrint("[CanaryMesh%lu] Registered with DetectorOne � "
        "TablePtr=%p\n", (ULONG)CANARY_ID, table);

    ExFreePoolWithTag(buffer, CANARY_POOL_TAG);
    ObDereferenceObject(fileObject);
    return STATUS_SUCCESS;
}

// ============================================================
// CanaryUnload
// ============================================================

VOID CanaryUnload(PDRIVER_OBJECT DriverObject) {
    UNREFERENCED_PARAMETER(DriverObject);

    DbgPrint("[CanaryMesh%lu] Unload requested\n", (ULONG)CANARY_ID);
    InterlockedExchange(&g_State.ShouldStop, 1);
    KeSetEvent(&g_State.AlertEvent, IO_NO_INCREMENT, FALSE);

    if (g_State.CallbackWatchThread) {
        KeWaitForSingleObject(g_State.CallbackWatchThread,
            Executive, KernelMode, FALSE, NULL);
        ObDereferenceObject(g_State.CallbackWatchThread);
        g_State.CallbackWatchThread = NULL;
    }
    if (g_State.HeartbeatThread) {
        KeWaitForSingleObject(g_State.HeartbeatThread,
            Executive, KernelMode, FALSE, NULL);
        ObDereferenceObject(g_State.HeartbeatThread);
        g_State.HeartbeatThread = NULL;
    }
    if (g_State.DriverWatchThread) {
        KeWaitForSingleObject(g_State.DriverWatchThread,
            Executive, KernelMode, FALSE, NULL);
        ObDereferenceObject(g_State.DriverWatchThread);
        g_State.DriverWatchThread = NULL;
    }

    if (g_State.Table) {
        PCANARY_IDENTITY mySlot =
            &g_State.Table->Canaries[g_State.CanaryId - 1];
        InterlockedExchange(&mySlot->Status, CANARY_STATUS_DEAD);
        InterlockedDecrement(&g_State.Table->AliveCount);
    }

    DbgPrint("[CanaryMesh%lu] Unloaded\n", (ULONG)CANARY_ID);
}

// ============================================================
// CanaryReceiveAlert � appel�e par DetectorOne (High Risk d�tect�)
// ============================================================

extern "C"
VOID NTAPI CanaryReceiveAlert(
    IN PWSTR            DriverName,
    IN PLARGE_INTEGER   LoadTimestamp,
    IN ULONG            RiskScore
) {
    ExAcquireFastMutex(&g_State.AlertLock);

    if (g_State.Alert.Active) {
        DbgPrint("[CanaryMesh%lu] Alert already active for %S � "
            "ignoring %S\n",
            (ULONG)CANARY_ID, g_State.Alert.DriverName, DriverName);
        ExReleaseFastMutex(&g_State.AlertLock);
        return;
    }

    InterlockedExchange(&g_State.Alert.Active, 1);
    InterlockedExchange(&g_State.Alert.DriverStillLoaded, 1);
    InterlockedExchange(&g_State.Alert.UnloadDetected, 0);
    InterlockedExchange(&g_State.Alert.CallbackRemovalDetected, 0);
    InterlockedExchange(&g_State.Alert.LivenessDropDetected, 0);
    InterlockedExchange(&g_State.Alert.DetectedSignals, 0);
    g_State.LivenessObservedAfterAlert = FALSE;

    RtlStringCchCopyW(g_State.Alert.DriverName,
        ARRAYSIZE(g_State.Alert.DriverName), DriverName);

    g_State.Alert.LoadTimestamp = *LoadTimestamp;
    g_State.Alert.RiskScore = RiskScore;
    KeQuerySystemTime(&g_State.Alert.ActivationTime);

    // Capturer la baseline des compteurs au moment T0 de l'alerte
    PCanaryMesh_EDR_CALLBACK_BASELINE baseline =
        &g_State.Table->CallbackBaseline;

    if (baseline->Valid && baseline->ProcessEventCounter) {
        g_State.LivenessProcessBaseline =
            InterlockedAdd64(
                (volatile LONG64*)baseline->ProcessEventCounter, 0);
    }
    if (baseline->Valid && baseline->ImageEventCounter) {
        g_State.LivenessImageBaseline =
            InterlockedAdd64(
                (volatile LONG64*)baseline->ImageEventCounter, 0);
    }

    KeQuerySystemTime(&g_State.LivenessBaselineCaptureTime);

    ExReleaseFastMutex(&g_State.AlertLock);
    KeSetEvent(&g_State.AlertEvent, IO_NO_INCREMENT, FALSE);

    DbgPrint("[CanaryMesh%lu] ALERT RECEIVED Driver=%S "
        "LoadTime=%lld Risk=%lu\n",
        (ULONG)CANARY_ID, DriverName,
        LoadTimestamp->QuadPart, RiskScore);
    DbgPrint("[CanaryMesh%lu]   Baseline: ProcessEvents=%lld "
        "ImageEvents=%lld\n",
        (ULONG)CANARY_ID,
        g_State.LivenessProcessBaseline,
        g_State.LivenessImageBaseline);
}

// ============================================================
// Thread 3 � Callback Watch (Signal A + Signal B)
// ============================================================

VOID CanaryCallbackWatchThread(PVOID Context) {
    UNREFERENCED_PARAMETER(Context);

    DbgPrint("[CanaryMesh%lu] Callback watch thread started\n",
        (ULONG)CANARY_ID);

    LARGE_INTEGER interval;
    interval.QuadPart =
        -(LONGLONG)(CanaryMesh_CALLBACK_CHECK_INTERVAL_MS * 10000);

    while (!g_State.ShouldStop) {

        LARGE_INTEGER timeout;
        timeout.QuadPart =
            -(LONGLONG)(CanaryMesh_ALERT_WINDOW_MS * 10000);

        NTSTATUS waitStatus = KeWaitForSingleObject(
            &g_State.AlertEvent, Executive, KernelMode, FALSE, &timeout);

        if (g_State.ShouldStop) break;

        if (waitStatus == STATUS_TIMEOUT) {
            if (g_State.Alert.Active)
                InterlockedExchange(&g_State.Alert.Active, 0);
            continue;
        }

        DbgPrint("[CanaryMesh%lu] Callback watch activated\n",
            (ULONG)CANARY_ID);

        while (!g_State.ShouldStop && g_State.Alert.Active) {

            PCanaryMesh_EDR_CALLBACK_BASELINE baseline =
                &g_State.Table->CallbackBaseline;

            if (!baseline->Valid) {
                KeDelayExecutionThread(KernelMode, FALSE, &interval);
                continue;
            }
            // -- SIGNAL A : any validated callback pointer removed
            BOOLEAN signalAEnabled =
                g_State.SignalAProcessBaselineValid ||
                g_State.SignalAImageBaselineValid ||
                g_State.SignalAThreadBaselineValid;

            if (signalAEnabled) {
                BOOLEAN processCallbackPresent = TRUE;
                BOOLEAN imageCallbackPresent = TRUE;
                BOOLEAN threadCallbackPresent = TRUE;

                if (g_State.SignalAProcessBaselineValid) {
                    processCallbackPresent = CanaryVerifyCallbackPointerForRoutine(
                        L"PsSetCreateProcessNotifyRoutineEx",
                        baseline->ProcessCallbackAddress,
                        &g_ProcessCallbackTableAddress);
                    if (!processCallbackPresent) {
                        processCallbackPresent = CanaryVerifyCallbackPointerForRoutine(
                            L"PsSetCreateProcessNotifyRoutine",
                            baseline->ProcessCallbackAddress,
                            &g_ProcessCallbackTableAddress);
                    }
                }

                if (g_State.SignalAImageBaselineValid) {
                    imageCallbackPresent = CanaryVerifyCallbackPointerForRoutine(
                        L"PsSetLoadImageNotifyRoutine",
                        baseline->ImageCallbackAddress,
                        &g_ImageCallbackTableAddress);
                }

                if (g_State.SignalAThreadBaselineValid) {
                    threadCallbackPresent = CanaryVerifyCallbackPointerForRoutine(
                        L"PsSetCreateThreadNotifyRoutine",
                        baseline->ThreadCallbackAddress,
                        &g_ThreadCallbackTableAddress);
                }

                if (!processCallbackPresent ||
                    !imageCallbackPresent ||
                    !threadCallbackPresent) {
                    if (!g_State.Alert.CallbackRemovalDetected) {
                        InterlockedExchange(
                            &g_State.Alert.CallbackRemovalDetected, 1);
                        KeQuerySystemTime(
                            &g_State.Alert.CallbackLossTimestamp);

                        LARGE_INTEGER now;
                        KeQuerySystemTime(&now);
                        LONGLONG lossLatencyMs =
                            (now.QuadPart -
                                g_State.Alert.ActivationTime.QuadPart) / 10000;

                        DbgPrint("[CanaryMesh%lu] SIGNAL A: CALLBACK POINTER REMOVED\n",
                            (ULONG)CANARY_ID);
                        DbgPrint("[CanaryMesh%lu]   Process=%u Image=%u Thread=%u LatencyMs=%lld\n",
                            (ULONG)CANARY_ID,
                            (ULONG)processCallbackPresent,
                            (ULONG)imageCallbackPresent,
                            (ULONG)threadCallbackPresent,
                            lossLatencyMs);

                        InterlockedOr(&g_State.Alert.DetectedSignals,
                            ALERT_CALLBACK_POINTER_REMOVED);
                        CanaryCastVote(ALERT_CALLBACK_POINTER_REMOVED);
                    }
                }
            }

            // -- SIGNAL B : Vivacit� des compteurs -------------
            if (!g_State.Alert.LivenessDropDetected) {
                if (CanaryIsLivenessCounterFrozen()) {
                    InterlockedExchange(
                        &g_State.Alert.LivenessDropDetected, 1);

                    LARGE_INTEGER now;
                    KeQuerySystemTime(&now);
                    LONGLONG frozenLatencyMs =
                        (now.QuadPart -
                            g_State.Alert.ActivationTime.QuadPart) / 10000;

                    DbgPrint("[CanaryMesh%lu] SIGNAL B: CALLBACK LIVENESS "
                        "FROZEN LatencyMs=%lld\n",
                        (ULONG)CANARY_ID, frozenLatencyMs);

                    BOOLEAN driverStillThere =
                        CanaryIsSuspectDriverLoaded(
                            g_State.Alert.DriverName);

                    if (driverStillThere) {
                        DbgPrint("[CanaryMesh%lu] SIGNAL B+: PERSISTENT "
                            "ATTACK � driver loaded + callbacks dead\n",
                            (ULONG)CANARY_ID);
                        InterlockedOr(&g_State.Alert.DetectedSignals,
                            ALERT_DRIVER_LOADED_CALLBACKS_DEAD);
                        CanaryCastVote(ALERT_DRIVER_LOADED_CALLBACKS_DEAD);
                    }
                    else {
                        InterlockedOr(&g_State.Alert.DetectedSignals,
                            ALERT_CALLBACK_LIVENESS_FROZEN);
                        CanaryCastVote(ALERT_CALLBACK_LIVENESS_FROZEN);
                    }
                }
            }

            KeDelayExecutionThread(KernelMode, FALSE, &interval);
        }

        KeClearEvent(&g_State.AlertEvent);
    }

    DbgPrint("[CanaryMesh%lu] Callback watch thread stopping\n",
        (ULONG)CANARY_ID);
    PsTerminateSystemThread(STATUS_SUCCESS);
}

// ============================================================
// Thread 2 � Driver Watch (Signal C)
// ============================================================

VOID CanaryDriverWatchThread(PVOID Context) {
    UNREFERENCED_PARAMETER(Context);

    DbgPrint("[CanaryMesh%lu] Driver watch thread started\n",
        (ULONG)CANARY_ID);

    LARGE_INTEGER pollInterval;
    pollInterval.QuadPart =
        -(LONGLONG)(CanaryMesh_DRIVER_POLL_INTERVAL_MS * 10000);

    while (!g_State.ShouldStop) {

        LARGE_INTEGER timeout;
        timeout.QuadPart =
            -(LONGLONG)(CanaryMesh_ALERT_WINDOW_MS * 10000);

        NTSTATUS waitStatus = KeWaitForSingleObject(
            &g_State.AlertEvent, Executive, KernelMode, FALSE, &timeout);

        if (g_State.ShouldStop) break;

        if (waitStatus == STATUS_TIMEOUT || !g_State.Alert.Active) {
            KeDelayExecutionThread(KernelMode, FALSE, &pollInterval);
            continue;
        }

        DbgPrint("[CanaryMesh%lu] Driver watch activated for %S\n",
            (ULONG)CANARY_ID, g_State.Alert.DriverName);

        while (!g_State.ShouldStop && g_State.Alert.Active) {

            BOOLEAN loaded =
                CanaryIsSuspectDriverLoaded(g_State.Alert.DriverName);

            if (!loaded &&
                g_State.Alert.DriverStillLoaded &&
                !g_State.Alert.UnloadDetected) {

                LARGE_INTEGER unloadTime;
                KeQuerySystemTime(&unloadTime);

                InterlockedExchange(&g_State.Alert.UnloadDetected, 1);
                InterlockedExchange(&g_State.Alert.DriverStillLoaded, 0);
                g_State.Alert.UnloadTimestamp = unloadTime;

                LONGLONG durationMs =
                    (unloadTime.QuadPart -
                        g_State.Alert.LoadTimestamp.QuadPart) / 10000;

                DbgPrint("[CanaryMesh%lu] SIGNAL C: Driver UNLOADED "
                    "Driver=%S DurationMs=%lld\n",
                    (ULONG)CANARY_ID,
                    g_State.Alert.DriverName, durationMs);

                if (durationMs < CanaryMesh_FAST_UNLOAD_THRESHOLD_MS) {
                    DbgPrint("[CanaryMesh%lu] SIGNAL C: FAST UNLOAD "
                        "� classic BYOVD pattern\n", (ULONG)CANARY_ID);
                    InterlockedOr(&g_State.Alert.DetectedSignals,
                        ALERT_DRIVER_UNLOADED_FAST);
                    CanaryCastVote(ALERT_DRIVER_UNLOADED_FAST);
                }
                else {
                    DbgPrint("[CanaryMesh%lu] SIGNAL C: Slow unload "
                        "DurationMs=%lld � correlate with A/B\n",
                        (ULONG)CANARY_ID, durationMs);
                }

                InterlockedExchange(&g_State.Alert.Active, 0);
                break;
            }

            KeDelayExecutionThread(KernelMode, FALSE, &pollInterval);
        }
    }

    DbgPrint("[CanaryMesh%lu] Driver watch thread stopping\n",
        (ULONG)CANARY_ID);
    PsTerminateSystemThread(STATUS_SUCCESS);
}

// ============================================================
// Thread 1 � Heartbeat P2P
// ============================================================

VOID CanaryHeartbeatThread(PVOID Context) {
    UNREFERENCED_PARAMETER(Context);

    PCanaryMesh_CANARY_TABLE table = g_State.Table;
    PCANARY_IDENTITY mySlot = &table->Canaries[g_State.CanaryId - 1];

    LARGE_INTEGER interval;
    interval.QuadPart = -(LONGLONG)(CanaryMesh_HEARTBEAT_INTERVAL_MS * 10000);

    while (!g_State.ShouldStop) {

        // Mettre � jour son propre heartbeat
        InterlockedExchange64(&mySlot->LastHeartbeatTime,
            (LONG64)KeQueryInterruptTime());
        InterlockedIncrement(&mySlot->HeartbeatSequence);
        InterlockedExchange(&mySlot->Status, CANARY_STATUS_ALIVE);

        // V�rifier les pairs
        ULONG aliveCount = 1;
        ULONG bound = (table->ExpectedCount > 0)
            ? table->ExpectedCount
            : CanaryMesh_MAX_CANARIES;

        for (ULONG i = 0; i < bound; i++) {
            if (i == g_State.CanaryId - 1) continue;

            // 1. Obtenir l'adresse brute
            ULONG_PTR rawAddr = (ULONG_PTR)&table->Canaries[i];

            // 2. Masquer le bit de poids faible au cas o� un tag (0x1) est pr�sent
            PCANARY_IDENTITY peer = (PCANARY_IDENTITY)(rawAddr & ~1ULL);

            // 3. Validation de pointeur de s�curit� basique en Kernel Mode
            if (!peer || (ULONG_PTR)peer < 0xFFFF800000000000ULL) continue;

            if (peer->CanaryId == 0) continue;

            //LONG64 elapsed = (LONG64)KeQueryInterruptTime() - peer->LastHeartbeatTime;
            
            LONG64 peerLastHeartbeat = InterlockedCompareExchange64((PLONG64)&peer->LastHeartbeatTime, 0, 0);
            LONG64 elapsed = (LONG64)KeQueryInterruptTime() - peerLastHeartbeat;
            LONGLONG elapsedMs = elapsed / 10000;

            if (elapsedMs < CanaryMesh_HEARTBEAT_TIMEOUT_MS) {
                aliveCount++;
                InterlockedExchange(&peer->Status, CANARY_STATUS_ALIVE);
            }
            else if (elapsedMs < CanaryMesh_HEARTBEAT_TIMEOUT_MS * 2) {
                InterlockedExchange(&peer->Status, CANARY_STATUS_SUSPECTED);
            }
            else {
                if (peer->Status != CANARY_STATUS_DEAD) {
                    InterlockedExchange(&peer->Status, CANARY_STATUS_DEAD);
                    DbgPrint("[CanaryMesh%lu] Peer Canary%lu DEAD "
                        "ElapsedMs=%lld\n",
                        (ULONG)CANARY_ID, i + 1, elapsedMs);
                    if (g_State.Alert.Active)
                        CanaryCastVote(ALERT_CANARY_PEER_DEAD);
                }
            }
        }

        InterlockedExchange(&table->AliveCount, (LONG)aliveCount);

        /*
        if (aliveCount < table->QuorumRequired) {
            DbgPrint("[CanaryMesh%lu] QUORUM DEGRADED Alive=%lu "
                "Required=%lu\n",
                (ULONG)CANARY_ID, aliveCount, table->QuorumRequired);
            if (g_State.Alert.Active)
                CanaryCastVote(ALERT_QUORUM_LOST);
        }*/
        if (aliveCount < table->QuorumRequired) {
            // Ne pas alerter pendant le bootstrap
            if (!table->HandoffComplete) {
                KeDelayExecutionThread(KernelMode, FALSE, &interval);
                continue;
            }
            DbgPrint("[CanaryMesh%lu] QUORUM DEGRADED Alive=%lu Required=%lu\n",
                (ULONG)CANARY_ID, aliveCount, table->QuorumRequired);
            if (g_State.Alert.Active)
                CanaryCastVote(ALERT_QUORUM_LOST);
        }

        KeDelayExecutionThread(KernelMode, FALSE, &interval);
    }

    PsTerminateSystemThread(STATUS_SUCCESS);
}

// ============================================================
// CanaryIsSuspectDriverLoaded � scan PsLoadedModuleList
// ============================================================


BOOLEAN CanaryIsSuspectDriverLoaded(IN PWSTR DriverBaseName) {

    UNREFERENCED_PARAMETER(DriverBaseName);

    if (!g_State.Table) return FALSE;

    // Lecture atomique du flag � aucun verrou, aucun deadlock
    return (InterlockedCompareExchange(
        &g_State.Table->SuspectDriverStillLoaded, 0, 0) == 1);
}


PVOID CanaryFindCallbackTableInCode(
    IN PUCHAR FunctionAddress,
    IN PCWSTR RoutineName,
    IN PVOID TargetCallback,
    IN ULONG Depth)
{
    if (!FunctionAddress || !RoutineName || !TargetCallback) return NULL;
    if ((ULONG_PTR)FunctionAddress < 0xFFFF800000000000ULL) return NULL;
    if (!MmIsAddressValid(FunctionAddress)) return NULL;

    for (ULONG i = 0; i < 2048; i++) {
        BOOLEAN ripRelative = FALSE;
        LONG disp = 0;
        PVOID candidate = NULL;

        // LEA r64, [RIP+disp32]
        if ((FunctionAddress[i] == 0x48 || FunctionAddress[i] == 0x4C) &&
            FunctionAddress[i + 1] == 0x8D &&
            (FunctionAddress[i + 2] >= 0x05 && FunctionAddress[i + 2] <= 0x3D &&
             (FunctionAddress[i + 2] & 0x07) == 0x05)) {
            disp = *(PLONG)(FunctionAddress + i + 3);
            candidate = FunctionAddress + i + 7 + disp;
            ripRelative = TRUE;
        }
        // MOV r64, [RIP+disp32]
        else if ((FunctionAddress[i] == 0x48 || FunctionAddress[i] == 0x4C) &&
            FunctionAddress[i + 1] == 0x8B &&
            (FunctionAddress[i + 2] >= 0x05 && FunctionAddress[i + 2] <= 0x3D &&
             (FunctionAddress[i + 2] & 0x07) == 0x05)) {
            disp = *(PLONG)(FunctionAddress + i + 3);
            candidate = FunctionAddress + i + 7 + disp;
            ripRelative = TRUE;
        }

        if (ripRelative) {
            if ((ULONG_PTR)candidate < 0xFFFF800000000000ULL) continue;
            if (!MmIsAddressValid(candidate)) continue;

            if (CanaryCallbackTableContains(candidate, TargetCallback, FALSE)) {
                DbgPrint("[CanaryMesh] Callback table from %S at %p contains %p\n",
                    RoutineName, candidate, TargetCallback);
                return candidate;
            }
        }

        // Follow one level of near CALLs. On newer builds the public PsSet*
        // export often delegates to an internal helper that owns the table ref.
        if (Depth == 0 && FunctionAddress[i] == 0xE8) {
            LONG callDisp = *(PLONG)(FunctionAddress + i + 1);
            PUCHAR callTarget = FunctionAddress + i + 5 + callDisp;

            if ((ULONG_PTR)callTarget < 0xFFFF800000000000ULL) continue;
            if (!MmIsAddressValid(callTarget)) continue;

            candidate = CanaryFindCallbackTableInCode(
                callTarget,
                RoutineName,
                TargetCallback,
                Depth + 1);
            if (candidate) return candidate;
        }
    }

    return NULL;
}

PVOID CanaryFindCallbackTableForRoutine(
    IN PCWSTR RoutineName,
    IN PVOID TargetCallback)
{
    if (!RoutineName || !TargetCallback) return NULL;

    UNICODE_STRING name;
    RtlInitUnicodeString(&name, RoutineName);
    PUCHAR fn = (PUCHAR)MmGetSystemRoutineAddress(&name);
    if (!fn) return NULL;

    PVOID table = CanaryFindCallbackTableInCode(
        fn,
        RoutineName,
        TargetCallback,
        0);

    if (!table) {
        DbgPrint("[CanaryMesh] No callback table from %S contains %p\n",
            RoutineName, TargetCallback);
    }

    return table;
}

BOOLEAN CanaryCallbackTableContains(
    IN PVOID TableAddress,
    IN PVOID TargetCallback,
    IN BOOLEAN Verbose)
{
    if (!TableAddress || !TargetCallback) return FALSE;

    __try {
        PULONG_PTR table = (PULONG_PTR)TableAddress;

        for (ULONG i = 0; i < 64; i++) {
            PVOID slotAddress = &table[i];
            if (!MmIsAddressValid(slotAddress)) break;

            ULONG_PTR entry = table[i];
            if (entry == 0) continue;

            if ((PVOID)entry == TargetCallback ||
                (PVOID)(entry & ~(ULONG_PTR)0xF) == TargetCallback) {
                if (Verbose) {
                    DbgPrint("[CanaryMesh] Table=%p[%lu]: direct function=%p\n",
                        TableAddress, i, (PVOID)entry);
                }
                return TRUE;
            }

            PEX_CALLBACK_ROUTINE_BLOCK block =
                (PEX_CALLBACK_ROUTINE_BLOCK)(entry & ~(ULONG_PTR)0xF);

            if ((ULONG_PTR)block < 0xFFFF800000000000ULL) continue;
            if (!MmIsAddressValid(block)) continue;
            if (!MmIsAddressValid((PUCHAR)block + FIELD_OFFSET(EX_CALLBACK_ROUTINE_BLOCK, Function))) continue;

            PVOID functionPtr = block->Function;
            if ((ULONG_PTR)functionPtr < 0xFFFF800000000000ULL) continue;

            if (Verbose) {
                DbgPrint("[CanaryMesh] Table=%p[%lu]: raw=%p block=%p function=%p\n",
                    TableAddress, i, (PVOID)entry, block, functionPtr);
            }

            if (functionPtr == TargetCallback ||
                (PVOID)((ULONG_PTR)functionPtr & ~(ULONG_PTR)0xF) == TargetCallback) return TRUE;
        }
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        if (Verbose) {
            DbgPrint("[CanaryMesh] Exception in callback scan: 0x%08X\n",
                GetExceptionCode());
        }
        return FALSE;
    }

    return FALSE;
}

BOOLEAN CanaryVerifyCallbackPointerForRoutine(
    IN PCWSTR RoutineName,
    IN PVOID TargetCallback,
    IN OUT PVOID* CachedTable)
{
    if (!RoutineName || !TargetCallback || !CachedTable) return FALSE;

    if (!*CachedTable) {
        *CachedTable = CanaryFindCallbackTableForRoutine(
            RoutineName,
            TargetCallback);
    }

    if (!*CachedTable) return FALSE;

    return CanaryCallbackTableContains(
        *CachedTable,
        TargetCallback,
        FALSE);
}

BOOLEAN CanaryVerifyCallbackPointerInTable(IN PVOID TargetCallback) {
    if (!TargetCallback) return FALSE;

    if (CanaryVerifyCallbackPointerForRoutine(
            L"PsSetCreateProcessNotifyRoutineEx",
            TargetCallback,
            &g_ProcessCallbackTableAddress)) {
        return TRUE;
    }

    return CanaryVerifyCallbackPointerForRoutine(
        L"PsSetCreateProcessNotifyRoutine",
        TargetCallback,
        &g_ProcessCallbackTableAddress);
}
// ============================================================
// CanaryIsLivenessCounterFrozen � Signal B
// ============================================================

/*
BOOLEAN CanaryIsLivenessCounterFrozen() {
    PCanaryMesh_EDR_CALLBACK_BASELINE baseline =
        &g_State.Table->CallbackBaseline;

    if (!baseline->Valid || !baseline->ProcessEventCounter ||
        !baseline->ImageEventCounter) return FALSE;

    LONG64 currentProcess =
        InterlockedAdd64(
            (volatile LONG64*)baseline->ProcessEventCounter, 0);
    LONG64 currentImage =
        InterlockedAdd64(
            (volatile LONG64*)baseline->ImageEventCounter, 0);

    LONG64 deltaProcess = currentProcess - g_State.LivenessProcessBaseline;
    LONG64 deltaImage = currentImage - g_State.LivenessImageBaseline;

    LARGE_INTEGER now;
    KeQuerySystemTime(&now);
    LONGLONG elapsedMs =
        (now.QuadPart - g_State.LivenessBaselineCaptureTime.QuadPart) / 10000;

    if (deltaProcess > 0 || deltaImage > 0) {
        g_State.LivenessObservedAfterAlert = TRUE;
        g_State.LivenessProcessBaseline = currentProcess;
        g_State.LivenessImageBaseline = currentImage;
        KeQuerySystemTime(&g_State.LivenessBaselineCaptureTime);
    }

    // Frozen only after at least one post-alert callback event was observed.
    if (elapsedMs >= CanaryMesh_LIVENESS_WINDOW_MS &&
        g_State.LivenessObservedAfterAlert &&
        deltaProcess == 0 && deltaImage == 0) {
        DbgPrint("[CanaryMesh%lu] Liveness FROZEN "
            "ElapsedMs=%lld ProcessDelta=%lld ImageDelta=%lld\n",
            (ULONG)CANARY_ID, elapsedMs, deltaProcess, deltaImage);
        return TRUE;
    }

    DbgPrint("[CanaryMesh%lu] Liveness OK "
        "ElapsedMs=%lld ProcessDelta=%lld ImageDelta=%lld\n",
        (ULONG)CANARY_ID, elapsedMs, deltaProcess, deltaImage);

    return FALSE;
}
*/
BOOLEAN CanaryIsLivenessCounterFrozen() {
    PCanaryMesh_EDR_CALLBACK_BASELINE baseline =
        &g_State.Table->CallbackBaseline;

    if (!baseline || !baseline->Valid) return FALSE;

    // 1. R�cup�ration des pointeurs de compteurs
    volatile LONG64* pProcessCounter = (volatile LONG64*)baseline->ProcessEventCounter;
    volatile LONG64* pImageCounter = (volatile LONG64*)baseline->ImageEventCounter;

    // 2. Sanity Check : Valider les pointeurs et v�rifier que les pages sont valides en m�moire
    if (!pProcessCounter || !pImageCounter) return FALSE;

    if (!MmIsAddressValid((PVOID)pProcessCounter) || !MmIsAddressValid((PVOID)pImageCounter)) {
        DbgPrint("[CanaryMesh%lu] WARNING: Event counter pages are invalid!\n", (ULONG)CANARY_ID);
        return FALSE;
    }

    // 3. Read atomique s�curis� (sans �criture lock xadd inutile)
    LONG64 currentProcess = InterlockedCompareExchange64(pProcessCounter, 0, 0);
    LONG64 currentImage = InterlockedCompareExchange64(pImageCounter, 0, 0);

    LONG64 deltaProcess = currentProcess - g_State.LivenessProcessBaseline;
    LONG64 deltaImage = currentImage - g_State.LivenessImageBaseline;

    LARGE_INTEGER now;
    KeQuerySystemTime(&now);
    LONGLONG elapsedMs =
        (now.QuadPart - g_State.LivenessBaselineCaptureTime.QuadPart) / 10000;

    if (deltaProcess > 0 || deltaImage > 0) {
        g_State.LivenessObservedAfterAlert = TRUE;
        g_State.LivenessProcessBaseline = currentProcess;
        g_State.LivenessImageBaseline = currentImage;
        KeQuerySystemTime(&g_State.LivenessBaselineCaptureTime);
    }

    // Frozen uniquement si des �v�nements post-alerte ont d�j� �t� observ�s au moins une fois
    if (elapsedMs >= CanaryMesh_LIVENESS_WINDOW_MS &&
        g_State.LivenessObservedAfterAlert &&
        deltaProcess == 0 && deltaImage == 0) {
        DbgPrint("[CanaryMesh%lu] Liveness FROZEN "
            "ElapsedMs=%lld ProcessDelta=%lld ImageDelta=%lld\n",
            (ULONG)CANARY_ID, elapsedMs, deltaProcess, deltaImage);
        return TRUE;
    }

    DbgPrint("[CanaryMesh%lu] Liveness OK "
        "ElapsedMs=%lld ProcessDelta=%lld ImageDelta=%lld\n",
        (ULONG)CANARY_ID, elapsedMs, deltaProcess, deltaImage);

    return FALSE;
}
// ============================================================
// Consensus P2P
// ============================================================


VOID CanaryCastVote(IN CanaryMesh_ALERT_TYPE AlertType) {
    PCanaryMesh_CANARY_TABLE table = g_State.Table;
    if (!table) return;

    LONG voteBit = (LONG)(1UL << (g_State.CanaryId - 1));
    LONG oldBitmap;
    LONG newBitmap;

    do {
        oldBitmap = InterlockedCompareExchange(
            &table->AlertVoteBitmap, 0, 0);
        if (oldBitmap & voteBit) {
            DbgPrint("[CanaryMesh%lu] Vote already recorded AlertType=%lu Bitmap=0x%X\n",
                (ULONG)CANARY_ID, (ULONG)AlertType, oldBitmap);
            return;
        }
        newBitmap = oldBitmap | voteBit;
    } while (InterlockedCompareExchange(
        &table->AlertVoteBitmap, newBitmap, oldBitmap) != oldBitmap);

    LONG votes = InterlockedIncrement(&table->AlertVotes);

    DbgPrint("[CanaryMesh%lu] Vote AlertType=%lu Votes=%ld/%lu Bitmap=0x%X Generation=%ld\n",
        (ULONG)CANARY_ID, (ULONG)AlertType,
        votes, table->QuorumRequired, newBitmap, table->AlertGeneration);

    if ((ULONG)votes >= table->QuorumRequired) {
        LONG previous =
            InterlockedCompareExchange(&table->ConsensusEmitted, 1, 0);
        if (previous == 0)
            CanaryEmitConsensusAlert(AlertType, votes);
    }
}



VOID CanaryEmitConsensusAlert(
    IN CanaryMesh_ALERT_TYPE AlertType,
    IN LONG Votes
) {
    PCanaryMesh_CANARY_TABLE table = g_State.Table;

    LONGLONG loadToUnloadMs = 0;
    if (g_State.Alert.UnloadDetected) {
        loadToUnloadMs =
            (g_State.Alert.UnloadTimestamp.QuadPart -
                g_State.Alert.LoadTimestamp.QuadPart) / 10000;
    }

    LONGLONG callbackLossMs = 0;
    if (g_State.Alert.CallbackRemovalDetected) {
        callbackLossMs =
            (g_State.Alert.CallbackLossTimestamp.QuadPart -
                g_State.Alert.LoadTimestamp.QuadPart) / 10000;
    }

    LARGE_INTEGER now;
    KeQuerySystemTime(&now);
    LONGLONG detectLatencyMs = (now.QuadPart - g_State.Alert.ActivationTime.QuadPart) / 10000;

    InterlockedExchange(&table->AlertActive, 0);

    DbgPrint("\n");
    DbgPrint("[CanaryMesh CONSENSUS] ===================================\n");
    DbgPrint("[CanaryMesh CONSENSUS] *** COLLEGIAL ALERT ***\n");
    DbgPrint("[CanaryMesh CONSENSUS] AlertType       = %lu\n", (ULONG)AlertType);
    DbgPrint("[CanaryMesh CONSENSUS] DetectedSignals = 0x%08X\n",
        (ULONG)g_State.Alert.DetectedSignals);
    DbgPrint("[CanaryMesh CONSENSUS] Votes           = %ld/%lu\n",
        Votes, table->QuorumRequired);
    DbgPrint("[CanaryMesh CONSENSUS] Driver          = %S\n",
        g_State.Alert.DriverName);
    DbgPrint("[CanaryMesh CONSENSUS] RiskScore       = %lu\n",
        g_State.Alert.RiskScore);
    DbgPrint("[CanaryMesh CONSENSUS] Signal A        = %u (callback pointer)\n",
        (ULONG)g_State.Alert.CallbackRemovalDetected);
    DbgPrint("[CanaryMesh CONSENSUS] Signal B        = %u (liveness frozen)\n",
        (ULONG)g_State.Alert.LivenessDropDetected);
    DbgPrint("[CanaryMesh CONSENSUS] Signal C        = %u (driver unloaded)\n",
        (ULONG)g_State.Alert.UnloadDetected);
    DbgPrint("[CanaryMesh CONSENSUS] CallbackLossMs  = %lld\n", callbackLossMs);
    DbgPrint("[CanaryMesh CONSENSUS] DriverDurationMs= %lld\n", loadToUnloadMs);
    DbgPrint("[CanaryMesh CONSENSUS] DetectLatencyMs = %lld\n", detectLatencyMs);
    DbgPrint("[CanaryMesh CONSENSUS] ActiveCanaries  = %ld\n",
        table->AliveCount);
    DbgPrint("[CanaryMesh CONSENSUS] ===================================\n");
    DbgPrint("\n");


}

// ============================================================
// Utilitaires
// ============================================================

NTSTATUS CanaryWaitForHandoff(IN PCanaryMesh_CANARY_TABLE Table) {
    LARGE_INTEGER interval;
    interval.QuadPart = -(200 * 10000LL);
    ULONG elapsed = 0;

    while (elapsed < CanaryMesh_HANDOFF_TIMEOUT_MS) {
        if (InterlockedCompareExchange(
            &Table->HandoffComplete, 1, 1) == 1)
            return STATUS_SUCCESS;
        KeDelayExecutionThread(KernelMode, FALSE, &interval);
        elapsed += 200;
    }
    return STATUS_TIMEOUT;
}

VOID CanaryLogState(IN PCSTR Context) {
    PCanaryMesh_CANARY_TABLE table = g_State.Table;
    if (!table) return;

    DbgPrint("[CanaryMesh%lu] State [%s] Registered=%ld Alive=%ld/%lu "
        "Quorum=%lu Handoff=%ld\n",
        (ULONG)CANARY_ID, Context,
        table->RegisteredCount,
        table->AliveCount,
        table->ExpectedCount,
        table->QuorumRequired,
        table->HandoffComplete);
}
